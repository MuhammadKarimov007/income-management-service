package core;

import org.junit.jupiter.api.Test;

public class CoreClassTest {

	@Test
	public void test() {
		new CoreClass().run();
	}

}
