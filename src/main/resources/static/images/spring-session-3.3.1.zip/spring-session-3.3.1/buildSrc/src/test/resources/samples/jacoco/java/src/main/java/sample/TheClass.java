package sample;

public class TheClass {
	public boolean doStuff(boolean b) {
		if(b) {
			return true;
		} else {
			return false;
		}
	}
}