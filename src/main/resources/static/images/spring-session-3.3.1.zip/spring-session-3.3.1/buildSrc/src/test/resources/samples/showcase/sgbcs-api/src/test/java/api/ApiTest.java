package api;

import org.junit.jupiter.api.Test;

public class ApiTest {

	@Test
	public void api() {}
}
