package sample;

import org.junit.jupiter.api.Test;
import jakarta.servlet.http.HttpServletRequest;

public class TheTest {
	@Test
	public void compilesAndRuns() {
		HttpServletRequest request = null;
	}
}